<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
class generate_token{
    public $conn;
    function __construct(){
        $servername = "localhost";
        $username = "root";
        $password = "";

        $shop = $_GET['shop'] ?? 'brijesh-singh1.myshopify.com';

        if(isset($_GET['code']) || true){
            $this->conn = new PDO("mysql:host=$servername;dbname=App", $username, $password);

            $sql = 'UPDATE user_setting SET payment_status = :payment_status WHERE shop = :shop';
            $statement = $this->conn->prepare($sql);
            $statement->execute([':payment_status'=>1,':shop'=>$shop]);
            header('location:index.php');
        }
        else
        {
            echo "Something went wrong";
        }
       
    }
}
$token = new generate_token();

?>