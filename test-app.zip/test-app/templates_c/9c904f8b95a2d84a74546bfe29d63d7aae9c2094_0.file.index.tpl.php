<?php
/* Smarty version 4.3.0, created on 2023-03-04 07:53:49
  from '/opt/lampp/htdocs/test-app/templates/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_6402eafd246268_60366239',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9c904f8b95a2d84a74546bfe29d63d7aae9c2094' => 
    array (
      0 => '/opt/lampp/htdocs/test-app/templates/index.tpl',
      1 => 1677912826,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6402eafd246268_60366239 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<head>
<title>Smarty</title>
</head>
<body>
Welcome Smarty
</body>
</html><?php }
}
