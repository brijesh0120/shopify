<?php
require_once ("DB.php");
class Mymodel {

    public $conn;
    
    function __construct() {

        $servername = "localhost";
        $username = "root";
        $password = "";

        $this->conn = new PDO("mysql:host=$servername;dbname=App", $username, $password);
    }

    function checkUser($shop)
    {   
            $sql= "SELECT * FROM user_setting WHERE shop=:shop";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute([':shop'=>$shop]);
            
            $count = $stmt->rowCount();
            if($count==0)
            {
                $data = ['hmac'=>$_GET['hmac'], 'host'=>$_GET['host'], 'shop'=>$shop];
                $sql = "INSERT INTO user_setting (hmac, host, shop) VALUES (:hmac, :host, :shop)";
                $stmt= $this->conn->prepare($sql);
                $stmt->execute($data);
            }

                $sql= "SELECT * FROM user_setting WHERE shop=:shop";
                $stmt = $this->conn->prepare($sql);
                $stmt->execute([':shop'=>$shop]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                return $user;
    }

    function getPayment($shop)
    {
       $user = $this->checkUser($shop);
       return $user['payment_status'];
    }

    function installApp($shop)
    {
        $sql= "SELECT * FROM app_setting";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $app = $stmt->fetch(PDO::FETCH_ASSOC);

        $client_id = $app['client_id'];
        $scope = $app['scope'];
        $redirect_url = $app['redirect_url'];
    
        $oauth = "https://$shop/admin/oauth/authorize?client_id=$client_id&scope=$scope&redirect_uri=http://localhost/test-app/index.php?payment=1";
        header('location:'.$oauth);
    

    }

    function PaymentApp($shop)
    {
        $sql= "SELECT * FROM app_setting";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $app = $stmt->fetch(PDO::FETCH_ASSOC);

        $params = $_GET;

        $query = array(
            "client_id" => $app['client_id'], // Your API key
            "client_secret" => $app['secret_id'], // Your app credentials (secret key)
            "code" => '5466241c714b95cb7ffd028361e6e813' // Grab the access key from the URL
          );
  
          // Generate access token URL
          $access_token_url = "https://" . $app['shop'] . "/admin/oauth/access_token";
          
          // Configure curl client and execute request
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch, CURLOPT_URL, $access_token_url);
          curl_setopt($ch, CURLOPT_POST, count($query));
          curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($query));
          $result = curl_exec($ch);
          curl_close($ch);
          
          // Store the access token
          $result = json_decode($result, true);
   

        if(isset($result['access_token']))
        {
          
            $sql = 'UPDATE user_setting SET acess_token = :acess_token, payment_status = :payment_status WHERE shop = :shop';
            $statement = $this->conn->prepare($sql);
            $statement->execute([':acess_token' => $result['access_token'], ':payment_status'=>1,':shop'=>$shop]);
            header('location:index.php'); 
        }
        else
        {
            echo "access Token not Found";
        }

    }

    public function getProduct($shop)
    {
 
        $token = "SWplI7gKAckAlF9QfAvv9yrI3grYsSkw";
        $query = array(
            "Content-type" => "application/json" // Tell Shopify that we're expecting a response in JSON format
        );

        // Run API call to get all products
        $products = $this->shopify_call($token, $shop, "/admin/products.json", array(), 'GET');

        // Get response
        $products = $products['response'];
    }

    function shopify_call($token, $shop, $api_endpoint, $query = array(), $headers = array(), $method = 'GET') {
    
        // Build URL
        $url = "https://" . $shop . ".myshopify.com" . $api_endpoint;
        if (is_null($query)) $url = $url . "?" . http_build_query($query);
    
        // Configure cURL
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_MAXREDIRS, 3);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 3);
        curl_setopt($curl, CURLOPT_SSLVERSION, 3);
        curl_setopt($curl, CURLOPT_USERAGENT, 'My New Shopify App v.1');
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        
        // Setup headers
        $request_headers[] = "Content-type: text/plain";
        $request_headers[] = "X-Shopify-Access-Token: " . $token;
        curl_setopt($curl, CURLOPT_HTTPHEADER, $request_headers);
        
        // Send request to Shopify and capture any errors
        $response = curl_exec($curl);
        $error_number = curl_errno($curl);
        $error_message = curl_error($curl);
        
        // Close cURL to be nice
        curl_close($curl);
        
        // Return an error is cURL has a problem
        if ($error_number) {
            return $error_message;
        } else {
            
            // No error, return Shopify's response by parsing out the body
            $response = preg_split("/\r\n\r\n|\n\n|\r\r/", $response, 2);
            return $response[1];
            
        }
        
    }

}
?>