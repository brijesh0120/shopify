<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
include('libs/Smarty.class.php');
require_once 'DB.php'; 
require_once 'Model.php'; 

class Home {

    public $model;
    
    function __construct() {
        $this->smarty = new Smarty;
        $this->smarty->template_dir = "templates";
        $this->smarty->compile_dir = "templates_c";
        $this->model = new Mymodel(); 

        $this->model->checkUser('brijesh-singh1.myshopify.com');
        $active = $this->model->getPayment('brijesh-singh1.myshopify.com');

        if($active==0)
        {
            $this->model->installApp('brijesh-singh1.myshopify.com');
        }
        elseif($active==1 || isset($_GET['payment']))
        {
            $this->model->PaymentApp('brijesh-singh1.myshopify.com');
        }
        elseif($active==2)
        {
            $this->welcome();
        }

    }
  
   function welcome()
   {
        // $data = $this->model->getProduct('brijesh-singh1.myshopify.com');
        $this->smarty->assign('title','Welcome');
        $this->smarty->display('index.tpl');
   } 


}

$class = new Home();



?>